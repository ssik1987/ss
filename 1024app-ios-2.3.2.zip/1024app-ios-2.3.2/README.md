# 1024app - iOS
草榴官方客户端，小草客户端，iOS
<br>
<br>

社区声明：<br>
https://t66y.com/notice.php

小草客户端讨论：<br>
https://t66y.com/read.php?tid=1648542

<br><br>
此页面仅提供下载安装包，并非开源项目
